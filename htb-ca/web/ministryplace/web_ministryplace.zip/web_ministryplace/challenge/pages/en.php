<div class="container-fluid px-0 parallax parallax-stars" data-speed="20">
<div class="parallax-container">
    <div class="parallax parallax-spacestation" data-speed="130"></div>
    <div class="parallax parallax-spaceshuttle" data-speed="200"></div>
    <div class="container text-shadow h-100">
        <div class="row h-100">
            <div class="col-12 my-auto text-center text-white">
                <h1 class="text-shadow display-1">Ministry of Defence</h1>
                <h3 class="text-shadow">Military police is cooporating with earth to create the biggest solar beam weapon.</h3>
            </div>
        </div>
    </div>
</div>
</div>